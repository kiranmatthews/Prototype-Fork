Roo reference image font v2

Every nonempty glyph has a separate, recorded built-in image_gen pass.
Original Roo contours provide the transparent alpha. The bake retains measured
reference light/color where available and adds the model's finer surface detail.
This is a PNG font with fixed lighting, not a live relighting renderer.

PNG cap band: 384 pixels. Use JSON crop rectangles, bearings, advances and kerning.
All placement values are in cap-band units. Multiply by the requested text size.
layouts.BONUS supplies the reference's per-letter optical placement.
Space has an advance and no bitmap. Both palettes have identical alpha masks.
See roo-font-v2-provenance.json for all 51 source hashes and prompts.
